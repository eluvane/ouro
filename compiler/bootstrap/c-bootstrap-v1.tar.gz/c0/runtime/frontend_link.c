#define _POSIX_C_SOURCE 200809L
/* runtime/frontend_link.c: generated-style split-frontend linker.
   Built into _build/gen/fe_link.c by scripts/ouro_build.py.
   Drives packed Ouro pipeline functions phase by phase and releases
   temporary arenas between units. Grammar, preprocessing, import resolution,
   lowering and checking remain in Ouro; C preserves typed failures and
   prints their diagnostics without retrying another compiler implementation.
   Type-app erasure belongs in extract.ouro, not here. */
#include "ouro_host_values.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdarg.h>

#define MAX_PATH 4096
#define FE_PARSE_ERR 10UL

int ouro_export_count_lx(void);
const char *ouro_export_name_lx(int i);
ouro_v *ouro_export_value_lx(int i);
int ouro_export_count_pa(void);
const char *ouro_export_name_pa(int i);
ouro_v *ouro_export_value_pa(int i);
int ouro_export_count_pb(void);
const char *ouro_export_name_pb(int i);
ouro_v *ouro_export_value_pb(int i);
int ouro_export_count_pf(void);
const char *ouro_export_name_pf(int i);
ouro_v *ouro_export_value_pf(int i);
int ouro_export_count_ds(void);
const char *ouro_export_name_ds(int i);
ouro_v *ouro_export_value_ds(int i);
int ouro_export_count_ir(void);
const char *ouro_export_name_ir(int i);
ouro_v *ouro_export_value_ir(int i);
int ouro_export_count_lr(void);
const char *ouro_export_name_lr(int i);
ouro_v *ouro_export_value_lr(int i);
int ouro_export_count_lo(void);
const char *ouro_export_name_lo(int i);
ouro_v *ouro_export_value_lo(int i);
int ouro_export_count_el(void);
const char *ouro_export_name_el(int i);
ouro_v *ouro_export_value_el(int i);
int ouro_export_count_co(void);
const char *ouro_export_name_co(int i);
ouro_v *ouro_export_value_co(int i);
int ouro_export_count_fc(void);
const char *ouro_export_name_fc(int i);
ouro_v *ouro_export_value_fc(int i);
int ouro_export_count_pi(void);
const char *ouro_export_name_pi(int i);
ouro_v *ouro_export_value_pi(int i);
int ouro_export_count_pr(void);
const char *ouro_export_name_pr(int i);
ouro_v *ouro_export_value_pr(int i);
int ouro_export_count_pl(void);
const char *ouro_export_name_pl(int i);
ouro_v *ouro_export_value_pl(int i);

static ouro_v *compile_to_cores_clos(ouro_env *env, ouro_v *fuel);
static ouro_v *compile_to_cores_src(ouro_env *env, ouro_v *src);
static ouro_v *compile_units_clos(ouro_env *env, ouro_v *fuel);
static ouro_v *compile_units_root(ouro_env *env, ouro_v *root);
static ouro_v *compile_units_files(ouro_env *env, ouro_v *files);
static ouro_v *compile_to_cores_impl(ouro_v *fuel, ouro_v *src);
static ouro_v *compile_units_impl(ouro_v *fuel, ouro_v *root, ouro_v *files);
static ouro_v *list_from_items(ouro_v **items, int n);
static ouro_v *perm_nil(void);
static ouro_v *perm_cons(ouro_v *head, ouro_v *tail);
static ouro_v *perm_pair(ouro_v *a, ouro_v *b);
static int collect_file_pairs(ouro_v *files, ouro_v ***out_items, int *out_n);
static ouro_v *pair_fst(ouro_v *p);
static ouro_v *pair_snd(ouro_v *p);

static ouro_v *find_exp(const char *name, int n, const char *(*nm)(int),
			ouro_v *(*val)(int))
{
	int i;
	for (i = 0; i < n; i++) {
		if (strcmp(nm(i), name) == 0)
			return val(i);
	}
	fprintf(stderr, "ouro1: frontend glue missing export %s\n", name);
	exit(2);
	return 0;
}

#define FIND(mod, name)                                                        \
	find_exp((name), ouro_export_count_##mod(), ouro_export_name_##mod,    \
		 ouro_export_value_##mod)




static ouro_v *cerr(unsigned long code, unsigned long det)
{
	ouro_v *err[2];
	ouro_v *box[1];
	err[0] = ouro_nat(code);
	err[1] = ouro_nat(det);
	box[0] = ouro_ctor(0, 2, err);
	return ouro_ctor(0, 1, box);
}

static ouro_v *g_closed_parse_file;
static ouro_v *g_last_intern;

ouro_v *ouro_fe_last_intern(void)
{
	return g_last_intern;
}

static void line_col(const char *s, size_t pos, int *line, int *col)
{
	size_t i;
	*line = 1;
	*col = 1;
	for (i = 0; i < pos && s[i]; i++) {
		if (s[i] == '\n') {
			(*line)++;
			*col = 1;
		} else
			(*col)++;
	}
}

static void print_diag(const char *code, const char *path, const char *src,
		       size_t pos, const char *msg, const char *hint)
{
	int line, col;
	const char *use = path && path[0] ? path : "<input>";
	line_col(src ? src : "", pos, &line, &col);
	fprintf(stderr, "%s error %s:%d:%d %s\n", code, use, line, col, msg);
	fprintf(stderr, "hint: %s\n", hint);
}

static char *src_from_codes(ouro_v *xs, size_t *out_n)
{
	char *buf = (char *)malloc(1 << 20);
	int n;
	if (buf == 0)
		return 0;
	n = codes_to_buf(xs, buf, 1 << 20);
	*out_n = (size_t)n;
	return buf;
}

/* ---- import / record post-fail mapping --------------------------------
   Expansion itself runs inside packed stitch_* (pi then pr). These
   helpers only print OURO-IMP-* / OURO-REC-* from CErr codes 81-84 /
   71-77.
   ------------------------------------------------------------------- */

static void imp_print_err(const char *path, ouro_v *src_codes,
			  unsigned long pos, unsigned long code)
{
	const char *cname = "OURO-IMP-001";
	const char *msg = "malformed import alias or local open";
	const char *hint =
		"Use: import \"path.ouro\" as Alias;  open Alias;  open Alias in expr;  Alias.name";
	char *src;
	size_t n = 0;
	switch ((int)code) {
	case 2:
		cname = "OURO-IMP-002";
		msg = "duplicate import alias";
		hint = "Each import alias name may appear only once in a file.";
		break;
	case 3:
		cname = "OURO-IMP-003";
		msg = "unknown import alias in open or qualifier";
		hint = "Open or qualify only an alias introduced by import \"path\" as Alias;";
		break;
	case 4:
		cname = "OURO-IMP-004";
		msg = "invalid import alias name";
		hint = "Choose a non-keyword identifier as the alias.";
		break;
	default:
		break;
	}
	src = src_from_codes(src_codes, &n);
	print_diag(cname, path && path[0] ? path : "<input>", src ? src : "",
		   (size_t)pos, msg, hint);
	free(src);
}

static void rec_print_err(const char *path, ouro_v *src_codes,
			  unsigned long code, unsigned long pos)
{
	const char *cname = "OURO-REC-001";
	const char *msg = "malformed record declaration";
	const char *hint = "Use: record Name : Type where field : Type; end;";
	char *src;
	size_t n = 0;
	switch ((int)code) {
	case 2:
		cname = "OURO-REC-002";
		msg = "duplicate record field";
		hint = "Each field name may appear only once in a record.";
		break;
	case 3:
		cname = "OURO-REC-003";
		msg = "record literal/update needs known expected record type";
		hint = "Give the enclosing definition a concrete record result type.";
		break;
	case 4:
		cname = "OURO-REC-004";
		msg = "missing required field in record literal";
		hint = "Assign every field declared by the record.";
		break;
	case 5:
		cname = "OURO-REC-005";
		msg = "unknown field in record literal";
		hint = "Remove the field or use the target record's exact field names.";
		break;
	case 6:
		cname = "OURO-REC-006";
		msg = "generated record constructor/accessor name collides";
		hint = "Rename the record, constructor or existing declaration.";
		break;
	case 7:
		cname = "OURO-REC-007";
		msg = "projection target is not a known record type or field is not known";
		hint = "Project only fields declared by the target record.";
		break;
	default:
		break;
	}
	src = src_from_codes(src_codes, &n);
	print_diag(cname, path && path[0] ? path : "<input>", src ? src : "",
		   (size_t)pos, msg, hint);
	free(src);
}

static int cerr_code(ouro_v *r)
{
	if (r == 0 || r->tag != 0 || r->n < 1 || OURO_F(r, 0) == 0 || OURO_F(r, 0)->n < 1)
		return -1;
	return (int)as_nat(OURO_F(OURO_F(r, 0), 0));
}

static int cerr_det(ouro_v *r)
{
	if (r == 0 || r->tag != 0 || r->n < 1 || OURO_F(r, 0) == 0 || OURO_F(r, 0)->n < 2)
		return 0;
	return (int)as_nat(OURO_F(OURO_F(r, 0), 1));
}

static int decl_name_from_intern(int id, char *buf, int cap)
{
	ouro_v *codes;
	if (g_last_intern == 0 || buf == 0 || cap <= 0)
		return 0;
	codes = ouro_apply(ouro_apply(FIND(pl, "name_of_id"), g_last_intern),
		ouro_nat((unsigned long)id));
	return codes_to_buf(codes, buf, cap);
}

static int print_prep_diag(const char *path, ouro_v *src, int code, int det)
{
	if (code == 11 || code == 12) {
		const char *kind = code == 11 ? "malformed token" : "lexer fuel exhausted";
		(void)src;
		fprintf(stderr, "%s: %s\n",
			path != 0 && path[0] != 0 ? path : "<input>", kind);
		return 1;
	}
	if (code >= 41 && code <= 46) {
		const char *msg = "declaration check failed";
		char namebuf[256];
		int have_name;
		(void)src;
		switch (code) {
		case 41: msg = "type mismatch"; break;
		case 42: msg = "declared type is not a type"; break;
		case 43: msg = "positivity"; break;
		case 44: msg = "checker fuel exhausted"; break;
		case 45: msg = "duplicate declaration"; break;
		case 46: msg = "malformed declaration/core plan"; break;
		}
		have_name = decl_name_from_intern(det, namebuf, (int)sizeof namebuf);
		fprintf(stderr, "%s: %s%s%s\n",
			path != 0 && path[0] != 0 ? path : "<input>", msg,
			have_name > 0 ? " in " : "", have_name > 0 ? namebuf : "");
		return 1;
	}
	if (code >= 81 && code <= 84) {
		imp_print_err(path, src, (unsigned long)det,
			      (unsigned long)(code - 80));
		return 1;
	}
	if (code >= 71 && code <= 77) {
		rec_print_err(path, src, (unsigned long)(code - 70),
			      (unsigned long)det);
		return 1;
	}
	if (code >= 61 && code <= 65) {
		const char *cname = "OURO-HOLE-001";
		const char *msg = "unresolved named hole";
		const char *hint =
			"Replace the named hole before release/profile checking.";
		switch (code) {
		case 62:
			cname = "OURO-DO-001";
			msg = "let! outside a do statement";
			hint = "Move let! under do or use an ordinary let.";
			break;
		case 63:
			cname = "OURO-PIPE-001";
			msg = "dangling or incomplete pipe";
			hint = "Write value |> function or remove/parenthesize the pipe.";
			break;
		case 64:
			cname = "OURO-LIST-001";
			msg = "list literal without known List A context";
			hint = "Add a declaration/ascription such as : List Nat.";
			break;
		case 65:
			cname = "OURO-LIST-002";
			msg = "invalid list literal syntax";
			hint = "Remove the trailing comma or close the list.";
			break;
		default:
			break;
		}
		{
			char *s;
			size_t n = 0;
			s = src_from_codes(src, &n);
			print_diag(cname, path && path[0] ? path : "<input>",
				   s ? s : "", (size_t)det, msg, hint);
			free(s);
		}
		return 1;
	}
	return 0;
}


static void print_units_diag(ouro_v *files, ouro_v *r)
{
	int code;
	char pbuf[MAX_PATH];
	ouro_v **items = 0;
	ouro_v *file = 0;
	int nitems = 0;
	if (r != 0 && r->tag == 1)
		return;
	code = cerr_code(r);
	pbuf[0] = 0;
	/* Collected units are dependency-first and the requested root is last. */
	if (collect_file_pairs(files, &items, &nitems) && nitems > 0)
		file = items[nitems - 1];
	free(items);
	if (file != 0 && file->n >= 2)
		codes_to_buf(pair_fst(file), pbuf, MAX_PATH);
	(void)print_prep_diag(pbuf, file != 0 ? pair_snd(file) : 0,
	                      code, cerr_det(r));
}

static ouro_v *pair_fst(ouro_v *p)
{
	if (p == 0 || p->n < 2)
		return 0;
	return OURO_F(p, p->n - 2);
}

static ouro_v *pair_snd(ouro_v *p)
{
	if (p == 0 || p->n < 1)
		return 0;
	return OURO_F(p, p->n - 1);
}

static ouro_v *closed_parse_file(void)
{
	ouro_v *fn;
	if (g_closed_parse_file != 0)
		return g_closed_parse_file;
	ouro_static_begin();
	fn = FIND(pf, "closed_parse_file");
	fn = ouro_apply(fn, FIND(pa, "parse_a"));
	fn = ouro_apply(fn, FIND(pb, "parse_b"));
	g_closed_parse_file = fn;
	ouro_static_end();
	return fn;
}

static ouro_v *g_stitch_source;

static ouro_v *packed_stitch_source(void)
{
	ouro_v *fn;
	if (g_stitch_source != 0)
		return g_stitch_source;
	ouro_static_begin();
	fn = FIND(pl, "stitch_source");
	fn = ouro_apply(fn, FIND(lx, "lex_go"));
	fn = ouro_apply(fn, closed_parse_file());
	fn = ouro_apply(fn, FIND(ds, "desugar_file"));
	fn = ouro_apply(fn, FIND(lo, "lower_expr_env2"));
	fn = ouro_apply(fn, FIND(co, "compile_program"));
	fn = ouro_apply(fn, FIND(el, "elaborate_surfaces"));
	fn = ouro_apply(fn, FIND(el, "elaborate_fuel"));
	fn = ouro_apply(fn, FIND(fc, "check_file_selected"));
	fn = ouro_apply(fn, FIND(pi, "preprocess_imports_reg"));
	fn = ouro_apply(fn, FIND(pr, "preprocess_records_reg"));
	g_stitch_source = fn;
	ouro_static_end();
	return fn;
}

static ouro_v *compile_to_cores_impl(ouro_v *fuel, ouro_v *src)
{
	ouro_v *pair;
	ouro_v *r;
	int code;
	pair = ouro_apply(ouro_apply(packed_stitch_source(), fuel), src);
	r = pair_fst(pair);
	g_last_intern = pair_snd(pair);
	if (r == 0 || r->tag != 1) {
		code = cerr_code(r);
		(void)print_prep_diag("", src, code, cerr_det(r));
	}
	return r != 0 ? r : cerr(FE_PARSE_ERR, 0);
}


static void fe_phase_done(const char *label);

static ouro_v *g_closed_preprocess_src;
static ouro_v *g_closed_parse_unit;
static ouro_v *g_closed_compile_from_decls;
static ouro_v *g_closed_remap_comp_files;

static ouro_v *closed_preprocess_src(void)
{
	ouro_v *fn;
	if (g_closed_preprocess_src != 0)
		return g_closed_preprocess_src;
	ouro_static_begin();
	fn = FIND(pl, "preprocess_src");
	fn = ouro_apply(fn, FIND(pi, "preprocess_imports_reg"));
	fn = ouro_apply(fn, FIND(pr, "preprocess_records_reg"));
	g_closed_preprocess_src = fn;
	ouro_static_end();
	return fn;
}

/* These non-reentrant seams share one lifetime protocol. Arguments and the
   caller's stack predate the mark; only the callee's temporaries are reclaimed.
   The selected clone operation preserves the data needed after the reset. */
static ouro_v *bounded_call(ouro_v *fn, int count, ouro_v **args,
			    ouro_v *(*clone_result)(ouro_v *))
{
	ouro_v *result;
	int i;
	ouro_heap_mark();
	for (i = 0; i < count; i++)
		fn = ouro_apply(fn, args[i]);
	result = clone_result(fn);
	ouro_heap_reset();
	return result;
}

static ouro_v *bounded_token_state(ouro_env *env, ouro_v *st)
{
	return bounded_call(FIND(lx, "next_token"), 3,
		(ouro_v *[]){ouro_get(env, 1), ouro_get(env, 0), st},
		ouro_clone_perm);
}

static ouro_v *bounded_token_source(ouro_env *env, ouro_v *src)
{
	return ouro_clos(bounded_token_state, ouro_cons(src, env));
}

static ouro_v *bounded_token_fuel(ouro_env *env, ouro_v *fuel)
{
	return ouro_clos(bounded_token_source, ouro_cons(fuel, env));
}

static ouro_v *closed_parse_unit(void)
{
	ouro_v *fn;
	if (g_closed_parse_unit != 0)
		return g_closed_parse_unit;
	ouro_static_begin();
	fn = FIND(pl, "parse_unit");
	fn = ouro_apply(fn, ouro_apply(FIND(lx, "lex_go_with"),
		ouro_clos(bounded_token_fuel, 0)));
	fn = ouro_apply(fn, FIND(lx, "intern_string"));
	fn = ouro_apply(fn, closed_parse_file());
	g_closed_parse_unit = fn;
	ouro_static_end();
	return fn;
}

/* The generated pipeline retains its own stack and phase values while lowering
   successive declarations. Reclaim only allocations made inside one lowerer
   call, after cloning its data result. This seam is not recursively re-entered:
   recursion inside lower_expr_env2 stays in the generated lowerer. */
static ouro_v *bounded_lower_expr(ouro_env *env, ouro_v *expr)
{
	return bounded_call(FIND(lo, "lower_expr_env2"), 3,
		(ouro_v *[]){ouro_get(env, 1), ouro_get(env, 0), expr},
		ouro_clone_perm_deep);
}

static ouro_v *bounded_lower_expected(ouro_env *env, ouro_v *expected)
{
	return ouro_clos(bounded_lower_expr, ouro_cons(expected, env));
}

static ouro_v *bounded_lower_environment(ouro_env *env, ouro_v *lower_env)
{
	return ouro_clos(bounded_lower_expected, ouro_cons(lower_env, env));
}

/* Only check_item's temporaries belong to this mark. The generated checker
   still owns selection, ordering and judgments. Existing permanent signature
   entries survive every item; cloning only the new result avoids repeatedly
   copying the growing environment. The enclosing pipeline deep-clones its
   final result before it resets either permanent bank. This seam is not
   re-entered by check_item's recursive term checks. */
static ouro_v *bounded_check_item(ouro_env *env, ouro_v *item)
{
	return bounded_call(FIND(fc, "check_item"), 3,
		(ouro_v *[]){ouro_get(env, 1), ouro_get(env, 0), item},
		ouro_clone_perm);
}

static ouro_v *bounded_check_signature(ouro_env *env, ouro_v *sig)
{
	return ouro_clos(bounded_check_item, ouro_cons(sig, env));
}

static ouro_v *bounded_check_fuel(ouro_env *env, ouro_v *fuel)
{
	return ouro_clos(bounded_check_signature, ouro_cons(fuel, env));
}

static ouro_v *closed_compile_from_decls(void)
{
	ouro_v *fn;
	if (g_closed_compile_from_decls != 0)
		return g_closed_compile_from_decls;
	ouro_static_begin();
	fn = FIND(pl, "compile_from_decls");
	fn = ouro_apply(fn, FIND(ds, "desugar_file"));
	fn = ouro_apply(fn, ouro_clos(bounded_lower_environment, 0));
	fn = ouro_apply(fn, FIND(co, "compile_program"));
	fn = ouro_apply(fn, FIND(el, "elaborate_surfaces"));
	fn = ouro_apply(fn, FIND(el, "elaborate_fuel"));
	fn = ouro_apply(fn, ouro_apply(FIND(fc, "check_file_selected_with"),
		ouro_clos(bounded_check_fuel, 0)));
	g_closed_compile_from_decls = fn;
	ouro_static_end();
	return fn;
}

/* Packed stitch_source/compile_from_decls never apply rewrite_handlers, so
   handle+operation clauses lower to hole0 (CErr 2). The rewrite TU is
   already in the seed; run it on DDef bodies after desugar. */
static ouro_v *rewrite_ddef_list(ouro_v *rw3, ouro_v *ds)
{
	ouro_v *d;
	ouro_v *d2;
	ouro_v *rest2;
	ouro_v *cell[2];
	ouro_v *fields[3];
	ouro_v *v;

	if (ds == 0 || ds->tag != 1 || ds->n < 2)
		return ds;
	d = OURO_F(ds, 0);
	if (d != 0 && d->tag == 0 && d->n >= 3) {
		fields[0] = OURO_F(d, 0);
		fields[1] = OURO_F(d, 1);
		fields[2] = ouro_apply(rw3, OURO_F(d, 2));
		ouro_perm_begin();
		d2 = ouro_ctor(0, 3, fields);
		ouro_perm_end();
	} else {
		d2 = d;
	}
	rest2 = rewrite_ddef_list(rw3, OURO_F(ds, 1));
	cell[0] = d2;
	cell[1] = rest2;
	ouro_perm_begin();
	v = ouro_ctor(1, 2, cell);
	ouro_perm_end();
	return v;
}

static ouro_v *rewrite_decls(ouro_v *fuel, ouro_v *st, ouro_v *ds)
{
	ouro_v *ds1;
	ouro_v *env;
	ouro_v *stack;
	ouro_v *rw3;

	ds1 = ouro_apply(FIND(ds, "desugar_file"), ds);
	env = ouro_apply(ouro_apply(FIND(pl, "collect_lower_env_from"), st), ds1);
	ouro_perm_begin();
	stack = ouro_ctor(0, 0, 0);
	ouro_perm_end();
	rw3 = ouro_apply(ouro_apply(ouro_apply(FIND(lr, "rewrite_handlers"), fuel), env),
		       stack);
	return rewrite_ddef_list(rw3, ds1);
}

/* Parsed AST detection prevents comments or string literals from enabling the
   destructive handler rewrite on an otherwise ordinary unit. */
static int decls_need_handler_rewrite(ouro_v *ds)
{
	ouro_v *result = ouro_apply(FIND(lr, "decls_need_handler_rewrite"), ds);
	return result != 0 && result->tag == 0 && result->n == 0;
}

static ouro_v *closed_remap_comp_files(void)
{
	ouro_v *fn;
	if (g_closed_remap_comp_files != 0)
		return g_closed_remap_comp_files;
	ouro_static_begin();
	fn = FIND(pl, "remap_comp_files");
	g_closed_remap_comp_files = fn;
	ouro_static_end();
	return fn;
}

static ouro_v *perm_nil(void)
{
	ouro_v *v;
	ouro_perm_begin();
	v = ouro_ctor(0, 0, 0);
	ouro_perm_end();
	return v;
}

static ouro_v *perm_cons(ouro_v *head, ouro_v *tail)
{
	ouro_v *cell[2];
	ouro_v *v;
	cell[0] = head;
	cell[1] = tail;
	ouro_perm_begin();
	v = ouro_ctor(1, 2, cell);
	ouro_perm_end();
	return v;
}


static ouro_v *perm_pair(ouro_v *a, ouro_v *b)
{
	ouro_v *cell[2];
	ouro_v *v;
	cell[0] = a;
	cell[1] = b;
	ouro_perm_begin();
	v = ouro_ctor(0, 2, cell);
	ouro_perm_end();
	return v;
}

static int append_unit(ouro_v ***items, int *n, int *cap, ouro_v *u)
{
	ouro_v **next;
	if (*n == *cap) {
		int nc = *cap == 0 ? 32 : *cap * 2;
		next = (ouro_v **)realloc(*items, (unsigned long)nc * sizeof(ouro_v *));
		if (next == 0)
			return 0;
		*items = next;
		*cap = nc;
	}
	(*items)[*n] = u;
	(*n)++;
	return 1;
}



static int collect_file_pairs(ouro_v *files, ouro_v ***out_items, int *out_n)
{
	ouro_v **items = 0;
	int n = 0;
	int cap = 0;
	ouro_v *cur = files;
	while (!list_done(cur)) {
		if (cur->tag != 1 || cur->n < 2) {
			free(items);
			return 0;
		}
		if (!append_unit(&items, &n, &cap, OURO_F(cur, 0))) {
			free(items);
			return 0;
		}
		cur = OURO_F(cur, 1);
	}
	*out_items = items;
	*out_n = n;
	return 1;
}

static ouro_v *list_from_items(ouro_v **items, int n)
{
	ouro_v *xs = perm_nil();
	int i;
	for (i = n - 1; i >= 0; i--)
		xs = perm_cons(items[i], xs);
	return xs;
}

static int unit_prepass_incremental(ouro_v *files, ouro_v **out_files,
				   ouro_v **out_error)
{
	ouro_v *preprocess_src = closed_preprocess_src();
	ouro_v *reg = FIND(pl, "empty_rec_reg_pl");
	ouro_v **in_items = 0;
	ouro_v **out_items = 0;
	int n = 0;
	int i;
	int ok = 1;
	if (!collect_file_pairs(files, &in_items, &n))
		return 0;
	if (n > 0) {
		out_items = (ouro_v **)calloc((unsigned long)n, sizeof(ouro_v *));
		if (out_items == 0) {
			free(in_items);
			return 0;
		}
	}
	for (i = 0; i < n; i++) {
		ouro_v *f = in_items[i];
		ouro_v *path;
		ouro_v *src;
		if (f == 0 || f->n < 2) {
			free(in_items);
			free(out_items);
			return 0;
		}
		path = ouro_clone_perm_deep(pair_fst(f));
		src = ouro_clone_perm_deep(pair_snd(f));
		in_items[i] = perm_pair(path, src);
	}
	for (i = n - 1; i >= 0; i--) {
		ouro_v *f = in_items[i];
		ouro_v *path;
		ouro_v *src;
		ouro_v *r;
		ouro_v *src2;
		if (f == 0 || f->n < 2) {
			ok = 0;
			break;
		}
		path = pair_fst(f);
		src = pair_snd(f);
		r = ouro_apply(ouro_apply(preprocess_src, reg), src);
		if (r == 0 || r->tag != 1 || r->n < 2) {
			if (r != 0 && r->tag == 0 && r->n >= 2)
				*out_error = ouro_clone_perm_deep(cerr(
					as_nat(pair_fst(r)), as_nat(pair_snd(r))));
			fe_phase_done("frontend-after-preprocess-unit-error");
			ok = 0;
			break;
		}
		reg = ouro_clone_perm_deep(OURO_F(r, r->n - 2));
		src2 = ouro_clone_perm_deep(OURO_F(r, r->n - 1));
		path = ouro_clone_perm_deep(path);
		out_items[i] = perm_pair(path, src2);
		fe_phase_done("frontend-after-preprocess-unit");
	}
	free(in_items);
	if (!ok) {
		free(out_items);
		return 0;
	}
	*out_files = list_from_items(out_items, n);
	free(out_items);
	return 1;
}

static int parse_units_incremental(ouro_v *fuel, ouro_v *files,
				   ouro_v **out_units, ouro_v **out_st,
				   ouro_v **out_error)
{
	ouro_v *parse_unit = closed_parse_unit();
	ouro_v *st = FIND(lx, "empty_intern");
	ouro_v **items = 0;
	int nitems = 0;
	int cap = 0;
	ouro_v *cur = files;
	int ok = 1;
	while (!list_done(cur)) {
		ouro_v *f;
		ouro_v *path;
		ouro_v *src;
		ouro_v *r;
		ouro_v *u;
		if (cur->tag != 1 || cur->n < 2) {
			ok = 0;
			break;
		}
		f = OURO_F(cur, 0);
		if (f == 0 || f->n < 2) {
			ok = 0;
			break;
		}
		path = pair_fst(f);
		src = pair_snd(f);
		r = ouro_apply(ouro_apply(ouro_apply(ouro_apply(parse_unit, fuel), st), path), src);
		if (r == 0 || r->tag != 0 || r->n < 2) {
			if (r != 0 && r->tag == 1 && r->n >= 3) {
				ouro_v *error = ouro_apply(ouro_apply(ouro_apply(
					FIND(pl, "frontend_parse_error"), files),
					OURO_F(r, 0)), OURO_F(r, 1));
				*out_st = ouro_clone_perm_deep(OURO_F(r, 2));
				*out_error = ouro_clone_perm_deep(ouro_ctor(0, 1, &error));
			}
			fe_phase_done("frontend-after-parse-unit-error");
			ok = 0;
			break;
		}
		u = ouro_clone_perm_deep(OURO_F(r, r->n - 2));
		st = ouro_clone_perm_deep(OURO_F(r, r->n - 1));
		if (!append_unit(&items, &nitems, &cap, u)) {
			fe_phase_done("frontend-after-parse-unit-oom");
			ok = 0;
			break;
		}
		fe_phase_done("frontend-after-parse-unit");
		cur = OURO_F(cur, 1);
	}
	if (!ok) {
		free(items);
		return 0;
	}
	*out_units = list_from_items(items, nitems);
	*out_st = st;
	free(items);
	return 1;
}

static void fe_phase_done(const char *label)
{
	ouro_heap_discard_phase();
	ouro_heap_report(label);
}

static ouro_v *compile_units_impl(ouro_v *fuel, ouro_v *root, ouro_v *files)
{
	ouro_v *files1 = 0;
	ouro_v *units = 0;
	ouro_v *st = 0;
	ouro_v *pair = 0;
	ouro_v *root_id = 0;
	ouro_v *selected = 0;
	ouro_v *st2 = 0;
	ouro_v *resolved = 0;
	ouro_v *ds = 0;
	ouro_v *fn = 0;
	ouro_v *r = 0;
	ouro_v *intern_fn = 0;
	ouro_v *resolve_fn = 0;
	ouro_v *falseb;

	/* Survivors are ouro_clone_perm_deep (static share only). Mid-cone
	   discard_phase then drops the parse/preprocess bump. Host prims
	   from ouro_fast live in the static heap so eqNat survives. */
	ouro_perm_reset_bank(0);
	ouro_perm_reset_bank(1);
	ouro_perm_select(0);
	fuel = ouro_clone_perm_deep(fuel);
	root = ouro_clone_perm_deep(root);
	files = ouro_clone_perm_deep(files);
	g_last_intern = FIND(lx, "empty_intern");

	if (!unit_prepass_incremental(files, &files1, &r))
		goto failed;
	fe_phase_done("frontend-after-preprocess");

	ouro_perm_select(1);
	if (!parse_units_incremental(fuel, files1, &units, &st, &r)) {
		if (st != 0)
			g_last_intern = st;
		goto failed;
	}
	fe_phase_done("frontend-after-parse-units");

	intern_fn = FIND(lx, "intern_string");
	resolve_fn = FIND(ir, "resolve_imports");
	ouro_perm_select(0);
	pair = ouro_apply(ouro_apply(intern_fn, st), root);
	root_id = pair_fst(pair);
	st2 = pair_snd(pair);
	selected = ouro_apply(ouro_apply(FIND(pl, "unit_decl_names"), units), root_id);
	resolved = ouro_apply(ouro_apply(resolve_fn, units), root_id);
	if (resolved == 0 || resolved->tag != 0) {
		g_last_intern = ouro_clone_perm_deep(st2);
		if (resolved != 0 && resolved->tag == 1 && resolved->n >= 2)
			r = ouro_clone_perm_deep(ouro_apply(ouro_apply(
				FIND(pl, "import_err"), pair_fst(resolved)), pair_snd(resolved)));
		fe_phase_done("frontend-after-resolve-error");
		goto failed;
	}
	ds = ouro_clone_perm_deep(OURO_F(resolved, 0));
	selected = ouro_clone_perm_deep(selected);
	st2 = ouro_clone_perm_deep(st2);
	ouro_perm_reset_bank(1);
	fe_phase_done("frontend-after-resolve-imports");

	ouro_perm_select(1);
	if (decls_need_handler_rewrite(ds)) {
		ds = rewrite_decls(fuel, st2, ds);
		ds = ouro_clone_perm_deep(ds);
		st2 = ouro_clone_perm_deep(st2);
	}
	fe_phase_done("frontend-after-rewrite-handlers");

	fn = closed_compile_from_decls();
	ouro_perm_select(1);
	r = ouro_apply(ouro_apply(ouro_apply(ouro_apply(fn, selected), fuel), st2), ds);
	/* Error classification scans the source cone. Keep only the result before
	   that scan, just as at the parse/resolve seams above. st2 and files1 are
	   already permanent; no generated caller retains phase-local values here. */
	r = ouro_clone_perm_deep(r);
	fe_phase_done("frontend-after-check-decls");
	falseb = ouro_ctor(0, 0, 0);
	r = ouro_apply(ouro_apply(ouro_apply(closed_remap_comp_files(), falseb), files1), r);
	g_last_intern = st2;
	print_units_diag(files1, r);
	r = ouro_clone_perm_deep(r);
	g_last_intern = ouro_clone_perm_deep(st2);
	ouro_perm_reset_bank(0);
	fe_phase_done("frontend-after-compile-from-decls");
	return r != 0 ? r : cerr(FE_PARSE_ERR, 0);

failed:
	/* Keep the original typed failure. Re-running an unbounded stitcher here
	   used to repeat failed work and could exhaust memory on rejected input. */
	if (r == 0)
		r = cerr(FE_PARSE_ERR, 0);
	print_units_diag(files1 != 0 ? files1 : files, r);
	return r;
}

static ouro_v *compile_to_cores_clos(ouro_env *env, ouro_v *fuel)
{
	(void)env;
	return ouro_clos(compile_to_cores_src, ouro_cons(fuel, 0));
}

static ouro_v *compile_to_cores_src(ouro_env *env, ouro_v *src)
{
	return compile_to_cores_impl(ouro_get(env, 0), src);
}

static ouro_v *compile_units_clos(ouro_env *env, ouro_v *fuel)
{
	(void)env;
	return ouro_clos(compile_units_root, ouro_cons(fuel, 0));
}

static ouro_v *compile_units_root(ouro_env *env, ouro_v *root)
{
	return ouro_clos(compile_units_files, ouro_cons(root, env));
}

static ouro_v *compile_units_files(ouro_env *env, ouro_v *files)
{
	return compile_units_impl(ouro_get(env, 1), ouro_get(env, 0), files);
}

static ouro_v *g_compile_to_cores;
static ouro_v *g_compile_units;

int ouro_export_count_fe(void)
{
	return 4;
}

const char *ouro_export_name_fe(int i)
{
	switch (i) {
	case 0:
		return "compile_units";
	case 1:
		return "compile_to_cores";
	case 2:
		return "lex_go";
	case 3:
		return "empty_intern";
	default:
		return "";
	}
}

ouro_v *ouro_export_value_fe(int i)
{
	switch (i) {
	case 0:
		if (g_compile_units == 0)
			g_compile_units = ouro_clos(compile_units_clos, 0);
		return g_compile_units;
	case 1:
		if (g_compile_to_cores == 0)
			g_compile_to_cores = ouro_clos(compile_to_cores_clos, 0);
		return g_compile_to_cores;
	case 2:
		return FIND(lx, "lex_go");
	case 3:
		return FIND(lx, "empty_intern");
	default:
		return 0;
	}
}
