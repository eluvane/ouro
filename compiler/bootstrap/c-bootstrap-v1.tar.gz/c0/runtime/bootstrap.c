/* Driver for the packed frontend/backend blob; it wires host globals but does not typecheck. */
#include "ouro_host_values.h"

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#ifdef _WIN32
#include <fcntl.h>
#include <io.h>
#endif

#define MAX_UNITS 512
#define MAX_NAME 256

int ouro_export_count_fe(void);
const char *ouro_export_name_fe(int i);
ouro_v *ouro_export_value_fe(int i);

int ouro_export_count_be(void);
const char *ouro_export_name_be(int i);
ouro_v *ouro_export_value_be(int i);

static ouro_v *find_in(const char *name, int n, const char *(*nm)(int),
		       ouro_v *(*val)(int))
{
	int i;
	for (i = 0; i < n; i++) {
		if (strcmp(nm(i), name) == 0)
			return val(i);
	}
	fprintf(stderr, "ouro1: no export named %s\n", name);
	exit(2);
	return 0;
}




static ouro_v *file_codes(const char *path)
{
	FILE *f = fopen(path, "rb");
	unsigned char *buf;
	long len;
	ouro_v *v;
	if (f == 0) {
		fprintf(stderr, "ouro1: cannot open %s\n", path);
		exit(2);
	}
	if (fseek(f, 0L, SEEK_END) != 0 || (len = ftell(f)) < 0) {
		fprintf(stderr, "ouro1: cannot size %s\n", path);
		fclose(f);
		exit(2);
	}
	rewind(f);
	buf = (unsigned char *)malloc((unsigned long)len + 1UL);
	if (buf == 0) {
		fputs("ouro1: out of memory\n", stderr);
		fclose(f);
		exit(1);
	}
	if (len > 0 && fread(buf, 1, (unsigned long)len, f) != (unsigned long)len) {
		fprintf(stderr, "ouro1: cannot read %s\n", path);
		free(buf);
		fclose(f);
		exit(2);
	}
	fclose(f);
	v = ouro_packed(buf, (unsigned long)len);
	free(buf);
	return v;
}

static ouro_v *path_bytes(const char *s)
{
	return ouro_packed((const unsigned char *)s, (unsigned long)strlen(s));
}

static ouro_v *unit_list_from(char **paths, int n)
{
	ouro_v *list = ouro_ctor(0, 0, 0);
	int i;
	for (i = n - 1; i >= 0; i--) {
		ouro_v *cell[2];
		cell[0] = path_bytes(paths[i]);
		cell[1] = file_codes(paths[i]);
		cell[0] = ouro_ctor(0, 2, cell);
		cell[1] = list;
		list = ouro_ctor(1, 2, cell);
	}
	return list;
}

static int is_fast(const char *name)
{
	/* Same host bindings the committed blob uses. Type apps are
	   dropped from JsIR before print_c, so these 2-arg forms match
	   call sites. */
	return strcmp(name, "add") == 0 || strcmp(name, "eqNat") == 0 ||
	       strcmp(name, "sub") == 0 || strcmp(name, "compareNat") == 0 ||
	       strcmp(name, "memNat") == 0 || strcmp(name, "append") == 0 ||
	       strcmp(name, "length") == 0 || strcmp(name, "reverse") == 0 ||
	       strcmp(name, "mul") == 0 || strcmp(name, "nth") == 0 ||
	       strcmp(name, "xor32") == 0 || strcmp(name, "and32") == 0 ||
	       strcmp(name, "or32") == 0 || strcmp(name, "not32") == 0 ||
	       strcmp(name, "shl32") == 0 || strcmp(name, "shr32") == 0 ||
	       strcmp(name, "rotr32") == 0 || strcmp(name, "add32") == 0;
}

/* Two of those host bindings do not have the shape the stdlib declares:
   ouro_rt.c's nth takes (list, index) while std/listx.ouro's nth takes
   (default, index, list), and memNat exists only inside selfhost, where the
   copies disagree on argument order. Programs get the Ouro definition. */
static int is_fast_shape_mismatch(const char *name)
{
	return strcmp(name, "nth") == 0 || strcmp(name, "memNat") == 0;
}

struct intern_name {
	unsigned long id;
	char s[MAX_NAME];
};

static void intern_push(struct intern_name **tab, int *n, int *cap,
			unsigned long id, const char *s)
{
	if (*n == *cap) {
		*cap = *cap == 0 ? 64 : *cap * 2;
		*tab = (struct intern_name *)realloc(
			*tab, (unsigned)(*cap) * sizeof(**tab));
		if (*tab == 0) {
			fputs("ouro1: out of memory\n", stderr);
			exit(1);
		}
	}
	(*tab)[*n].id = id;
	snprintf((*tab)[*n].s, MAX_NAME, "%s", s);
	(*n)++;
}

static void walk_ids(ouro_v *xs, struct intern_name **tab, int *n, int *cap)
{
	ouro_v *stack[256];
	int sp = 0;
	stack[sp++] = xs;
	while (sp > 0) {
		ouro_v *cur = stack[--sp];
		char buf[MAX_NAME];
		if (list_done(cur))
			continue;
		if (cur->tag == OURO_TAG_CAT && cur->n == 2) {
			if (sp + 2 > 256)
				continue;
			stack[sp++] = OURO_F(cur, 1);
			stack[sp++] = OURO_F(cur, 0);
			continue;
		}
		if (cur->tag == 1 && cur->n == 2) {
			ouro_v *p = OURO_F(cur, 0);
			if (p != 0 && p->n >= 2) {
				codes_to_buf(OURO_F(p, 0), buf, MAX_NAME);
				intern_push(tab, n, cap, as_nat(OURO_F(p, 1)), buf);
			}
			stack[sp++] = OURO_F(cur, 1);
		}
	}
}

static void recover_names_from_intern(ouro_v *st, struct intern_name **tab,
				      int *nn)
{
	int cap = 0;
	*tab = 0;
	*nn = 0;
	if (st == 0 || st->n < 1)
		return;
	walk_ids(OURO_F(st, 0), tab, nn, &cap);
}

static const char *lookup_name(struct intern_name *tab, int n, unsigned long id)
{
	int i;
	for (i = 0; i < n; i++) {
		if (tab[i].id == id)
			return tab[i].s;
	}
	return 0;
}

static ouro_v *names_list(struct intern_name *tab, int ntab, ouro_v **orig_ids,
			  int n)
{
	ouro_v *list = ouro_ctor(0, 0, 0);
	int i;
	for (i = n - 1; i >= 0; i--) {
		unsigned long id = as_nat(orig_ids[i]);
		const char *nm = lookup_name(tab, ntab, id);
		ouro_v *cell[2];
		ouro_v *pr[2];
		char fallback[32];
		if (nm == 0) {
			snprintf(fallback, sizeof fallback, "c%lu", id);
			nm = fallback;
		}
		pr[0] = orig_ids[i];
		pr[1] = ouro_bytes((const unsigned char *)nm,
				   (unsigned long)strlen(nm));
		cell[0] = ouro_ctor(0, 2, pr);
		cell[1] = list;
		list = ouro_ctor(1, 2, cell);
	}
	return list;
}

/* Full-length copy of an interned byte list (codes_to_buf truncates at
   MAX_NAME, which is fine for identifiers but not for string literals). */
static char *codes_to_heap(ouro_v *xs, unsigned long *len_out)
{
	unsigned long cap = 64;
	unsigned long n = 0;
	char *buf = (char *)malloc(cap);
	ouro_v *stack[64];
	int sp = 0;
	if (buf == 0) {
		fputs("ouro1: out of memory\n", stderr);
		exit(1);
	}
	for (;;) {
		if (list_done(xs)) {
			if (sp == 0)
				break;
			xs = stack[--sp];
			continue;
		}
		if (xs->tag == OURO_TAG_CAT && xs->n == 2) {
			if (sp < 63)
				stack[sp++] = OURO_F(xs, 1);
			xs = OURO_F(xs, 0);
			continue;
		}
		if (xs->tag == OURO_TAG_BYTES) {
			unsigned long k = (unsigned long)xs->n;
			while (n + k + 1 > cap)
				cap *= 2;
			buf = (char *)realloc(buf, cap);
			if (buf == 0) {
				fputs("ouro1: out of memory\n", stderr);
				exit(1);
			}
			if (k > 0 && xs->u.s != 0)
				memcpy(buf + n, xs->u.s, (size_t)k);
			n += k;
			if (sp == 0)
				break;
			xs = stack[--sp];
			continue;
		}
		if (xs->tag == 1 && xs->n == 2) {
			if (n + 2 > cap) {
				cap *= 2;
				buf = (char *)realloc(buf, cap);
				if (buf == 0) {
					fputs("ouro1: out of memory\n",
					      stderr);
					exit(1);
				}
			}
			buf[n++] = (char)(as_nat(OURO_F(xs, 0)) & 0xFFUL);
			xs = OURO_F(xs, 1);
			continue;
		}
		break;
	}
	buf[n] = 0;
	*len_out = n;
	return buf;
}

static int shim_is_prim_name(const char *nm)
{
	return strcmp(nm, "io_pure") == 0 || strcmp(nm, "io_bind") == 0 ||
	       strncmp(nm, "prim_", 5) == 0;
}

struct shim_entry {
	char *bytes;
	unsigned long len;
	unsigned long id;
};

/* Flatten a lexer alist (List (Pair (List Nat) Nat)) into an array. */
static struct shim_entry *collect_alist(ouro_v *xs, int *n_out)
{
	struct shim_entry *out = 0;
	int n = 0;
	int cap = 0;
	ouro_v *stack[256];
	int sp = 0;
	*n_out = 0;
	if (xs == 0)
		return 0;
	stack[sp++] = xs;
	while (sp > 0) {
		ouro_v *cur = stack[--sp];
		if (list_done(cur))
			continue;
		if (cur->tag == OURO_TAG_CAT && cur->n == 2) {
			if (sp + 2 > 256)
				continue;
			stack[sp++] = OURO_F(cur, 1);
			stack[sp++] = OURO_F(cur, 0);
			continue;
		}
		if (cur->tag == 1 && cur->n == 2) {
			ouro_v *p = OURO_F(cur, 0);
			stack[sp++] = OURO_F(cur, 1);
			if (p == 0 || p->n < 2)
				continue;
			if (n == cap) {
				cap = cap == 0 ? 64 : cap * 2;
				out = (struct shim_entry *)realloc(
					out, (unsigned)cap * sizeof(*out));
				if (out == 0) {
					fputs("ouro1: out of memory\n", stderr);
					exit(1);
				}
			}
			out[n].bytes = codes_to_heap(OURO_F(p, 0), &out[n].len);
			out[n].id = as_nat(OURO_F(p, 1));
			n++;
		}
	}
	*n_out = n;
	return out;
}

static void free_alist(struct shim_entry *xs, int n)
{
	int i;
	for (i = 0; i < n; i++)
		free(xs[i].bytes);
	free(xs);
}

static void shim_emit_c_string(const char *s, unsigned long len)
{
	unsigned long i;
	putchar('"');
	for (i = 0; i < len; i++) {
		unsigned char c = (unsigned char)s[i];
		if (c == '"' || c == '\\') {
			putchar('\\');
			putchar((int)c);
		} else if (c >= 32 && c < 127) {
			putchar((int)c);
		} else {
			printf("\\%03o", (unsigned)c);
		}
	}
	putchar('"');
}

/* Standalone-program mode (OURO_EMIT_IO_SHIMS=1). Two kinds of global the
   compiler-emission path never has to resolve:

     - runtime axioms (io_pure / io_bind / prim_*), bound here to the C host
       in ouro_io.c;
     - string literals, which print_c.ouro spells `ouro_gN` from the lexer's
       string table — an id space disjoint from name ids, so the two would
       otherwise collide. String ids are shifted by g_str_base and the IR is
       rewritten to match (see rewrite_node).

   Emitted before any global definition, so C sees a declaration first.
   Literals a program never forces stay dead statics. */
static unsigned long g_str_base;

/* Ids of globals with no runtime value: type-level defs such as `String`.
   extract.ouro erases a `(A : Type)` binder from every definition but only
   drops a type *argument* when its head is CInd/CSort/CPi or an erased Rel,
   so a synonym like `String` survives in the spine and the call site ends up
   one argument wider than the callee. Collected here, dropped in
   rewrite_jsir for IO programs only. Empty unless OURO_EMIT_IO_SHIMS
   is set. Module-defined aliases are classified from the full CoreTerm list
   by backend.ouro before per-definition extraction. */
static unsigned long *g_type_ids;
static int g_ntype;
static int g_type_cap;
static unsigned long g_typearg_drops;

static void type_id_push(unsigned long id)
{
	if (g_ntype == g_type_cap) {
		g_type_cap = g_type_cap == 0 ? 64 : g_type_cap * 2;
		g_type_ids = (unsigned long *)realloc(
			g_type_ids, (unsigned)g_type_cap * sizeof(*g_type_ids));
		if (g_type_ids == 0) {
			fputs("ouro1: out of memory\n", stderr);
			exit(1);
		}
	}
	g_type_ids[g_ntype++] = id;
}

static int is_type_id(unsigned long id)
{
	int i;
	for (i = 0; i < g_ntype; i++) {
		if (g_type_ids[i] == id)
			return 1;
	}
	return 0;
}

static void emit_runtime_shims(ouro_v *st, ouro_v **ids, int nids)
{
	struct shim_entry *names;
	struct shim_entry *strs = 0;
	int nnames = 0;
	int nstrs = 0;
	int i;
	int j;
	if (st == 0 || st->n < 1)
		return;
	names = collect_alist(OURO_F(st, 0), &nnames);
	if (st->n >= 3)
		strs = collect_alist(OURO_F(st, 2), &nstrs);

	g_str_base = 1;
	for (i = 0; i < nnames; i++) {
		if (names[i].id >= g_str_base)
			g_str_base = names[i].id + 1;
	}
	for (i = 0; i < nids; i++) {
		if (as_nat(ids[i]) >= g_str_base)
			g_str_base = as_nat(ids[i]) + 1;
	}

	fputs("ouro_v *ouro_io_prim_req(const char *name);\n", stdout);
	fputs("ouro_v *ouro_io_type_stub(const char *name);\n", stdout);
	for (i = 0; i < nnames; i++) {
		int skip = 0;
		int is_prim = shim_is_prim_name(names[i].bytes);
		const char *maker = is_prim ? "ouro_io_prim_req" :
					      "ouro_io_type_stub";
		for (j = 0; j < nids && !skip; j++) {
			if (as_nat(ids[j]) == names[i].id)
				skip = 1;
		}
		for (j = 0; j < i && !skip; j++) {
			if (names[j].id == names[i].id)
				skip = 1;
		}
		if (skip)
			continue;
		if (!is_prim)
			type_id_push(names[i].id);
		printf("static ouro_v *ouro_c%lu;\n", names[i].id);
		printf("static ouro_v *ouro_g%lu(void){if(ouro_c%lu==0)"
		       "ouro_c%lu=%s(\"%s\");return ouro_c%lu;}\n",
		       names[i].id, names[i].id, names[i].id, maker,
		       names[i].bytes, names[i].id);
	}
	for (i = 0; i < nstrs; i++) {
		unsigned long id = g_str_base + strs[i].id;
		printf("static ouro_v *ouro_c%lu;\n", id);
		printf("static ouro_v *ouro_g%lu(void){if(ouro_c%lu==0)"
		       "ouro_c%lu=ouro_str(",
		       id, id, id);
		shim_emit_c_string(strs[i].bytes, strs[i].len);
		printf(");return ouro_c%lu;}\n", id);
	}
	free_alist(names, nnames);
	free_alist(strs, nstrs);
}

/* JsIR tags match compiler/jsir.ouro constructor order. */
#define J_VAR 0
#define J_GLOB 1
#define J_LAM 2
#define J_APP 3
#define J_CTOR 4
#define J_SWITCH 5
#define J_FIX 6
#define J_LET 7
#define J_ERR 8
#define J_STR 9

static int js_nil(ouro_v *xs)
{
	return xs == 0 || (xs->tag == 0 && xs->n == 0) ||
	       (xs->tag == OURO_TAG_NAT && xs->n == 0);
}

static ouro_v *js_cons(ouro_v *h, ouro_v *t)
{
	ouro_v *c[2];
	c[0] = h;
	c[1] = t;
	return ouro_ctor(1, 2, c);
}

static ouro_v *js_append(ouro_v *a, ouro_v *b)
{
	if (js_nil(a))
		return b;
	if (!(a->tag == 1 && a->n >= 2))
		return b;
	return js_cons(OURO_F(a, 0), js_append(OURO_F(a, 1), b));
}

static ouro_v *peel_apps(ouro_v *j, ouro_v **args_out)
{
	/* Collect args by walking to the head, then reverse so the
	   leftmost application is first (type args come first). */
	ouro_v *stack[256];
	int n = 0;
	while (j != 0 && j->tag == J_APP && j->n >= 2) {
		if (n >= 256) {
			fputs("ouro1: app spine too deep\n", stderr);
			exit(1);
		}
		stack[n++] = OURO_F(j, 1);
		j = OURO_F(j, 0);
	}
	{
		/* stack[0] is the rightmost arg. cons front-to-back
		   from index 0 so the list is leftmost-first. */
		ouro_v *args = ouro_ctor(0, 0, 0);
		int i;
		for (i = 0; i < n; i++)
			args = js_cons(stack[i], args);
		*args_out = args;
	}
	return j;
}

static ouro_v *rebuild_apps(ouro_v *base, ouro_v *args)
{
	while (!js_nil(args) && args->tag == 1 && args->n >= 2) {
		ouro_v *f[2];
		f[0] = base;
		f[1] = OURO_F(args, 0);
		base = ouro_ctor(J_APP, 2, f);
		args = OURO_F(args, 1);
	}
	return base;
}

static ouro_v *rewrite_jsir(ouro_v *j);

static ouro_v *rewrite_list(ouro_v *xs)
{
	if (js_nil(xs))
		return xs;
	if (!(xs->tag == 1 && xs->n >= 2))
		return xs;
	return js_cons(rewrite_jsir(OURO_F(xs, 0)), rewrite_list(OURO_F(xs, 1)));
}

/* IO-program walk only: shift string ids and drop type-stub spine args.
   Stage emit skips this; extract.ouro already normalized the IR. */
static ouro_v *rewrite_node(ouro_v *j)
{
	ouro_v *fld[3];
	if (j == 0)
		return j;
	switch (j->tag) {
	case J_LAM:
		if (j->n < 2)
			return j;
		fld[0] = OURO_F(j, 0);
		fld[1] = rewrite_jsir(OURO_F(j, 1));
		return ouro_ctor(J_LAM, 2, fld);
	case J_CTOR:
		if (j->n < 3)
			return j;
		fld[0] = OURO_F(j, 0);
		fld[1] = OURO_F(j, 1);
		fld[2] = rewrite_list(OURO_F(j, 2));
		return ouro_ctor(J_CTOR, 3, fld);
	case J_SWITCH:
		if (j->n < 3)
			return j;
		fld[0] = rewrite_jsir(OURO_F(j, 0));
		fld[1] = OURO_F(j, 1);
		fld[2] = rewrite_list(OURO_F(j, 2));
		return ouro_ctor(J_SWITCH, 3, fld);
	case J_FIX:
		if (j->n < 3)
			return j;
		fld[0] = OURO_F(j, 0);
		fld[1] = OURO_F(j, 1);
		fld[2] = rewrite_jsir(OURO_F(j, 2));
		return ouro_ctor(J_FIX, 3, fld);
	case J_LET:
		if (j->n < 3)
			return j;
		fld[0] = OURO_F(j, 0);
		fld[1] = rewrite_jsir(OURO_F(j, 1));
		fld[2] = rewrite_jsir(OURO_F(j, 2));
		return ouro_ctor(J_LET, 3, fld);
	case J_STR:
		/* String ids live in their own space; shift them clear of the
		   name ids so both can share the ouro_gN spelling. */
		if (g_str_base == 0 || j->n < 1)
			return j;
		fld[0] = ouro_nat(g_str_base + as_nat(OURO_F(j, 0)));
		return ouro_ctor(J_GLOB, 1, fld);
	default:
		return j;
	}
}

/* A spine argument carries no runtime value when its head is a type-level
   global: `String`, `List String`, ... (see g_type_ids). */
static int is_type_arg(ouro_v *j)
{
	while (j != 0 && j->tag == J_APP && j->n >= 2)
		j = OURO_F(j, 0);
	return j != 0 && j->tag == J_GLOB && j->n >= 1 &&
	       is_type_id(as_nat(OURO_F(j, 0)));
}

static ouro_v *drop_type_args(ouro_v *args)
{
	ouro_v *kept;
	if (g_ntype == 0 || js_nil(args))
		return args;
	if (!(args->tag == 1 && args->n >= 2))
		return args;
	kept = drop_type_args(OURO_F(args, 1));
	if (is_type_arg(OURO_F(args, 0))) {
		g_typearg_drops++;
		return kept;
	}
	return js_cons(OURO_F(args, 0), kept);
}

static ouro_v *rewrite_jsir(ouro_v *j)
{
	ouro_v *fld[3];
	ouro_v *args;
	ouro_v *base;
	ouro_v *all;
	if (j == 0)
		return j;
	base = peel_apps(j, &args);
	base = rewrite_node(base);
	args = rewrite_list(args);
	args = drop_type_args(args);
	if (base != 0 && base->tag == J_CTOR && base->n >= 3) {
		all = js_append(drop_type_args(OURO_F(base, 2)), args);
		fld[0] = OURO_F(base, 0);
		fld[1] = OURO_F(base, 1);
		fld[2] = all;
		return ouro_ctor(J_CTOR, 3, fld);
	}
	return rebuild_apps(base, args);
}

#define CT_REL 0
#define CT_SORT 1
#define CT_PI 2
#define CT_LAM 3
#define CT_APP 4
#define CT_LET 5
#define CT_CONST 6
#define CT_IND 7
#define CT_CTOR 8
#define CT_CASE 9
#define CT_FIX 10
#define CT_STR 11

static void json_quoted(FILE *f, const char *s)
{
	fputc('"', f);
	if (s != 0) {
		for (; *s != 0; s++) {
			unsigned char c = (unsigned char)*s;
			if (c == '"' || c == '\\') {
				fputc('\\', f);
				fputc((char)c, f);
			} else if (c == '\n') {
				fputs("\\n", f);
			} else if (c < 32) {
				fprintf(f, "\\u%04x", (unsigned)c);
			} else {
				fputc((char)c, f);
			}
		}
	}
	fputc('"', f);
}

static const char *artifact_name(struct intern_name *tab, int ntab,
				unsigned long id)
{
	const char *nm = lookup_name(tab, ntab, id);
	return nm != 0 ? nm : "";
}

static void write_core_term(FILE *f, ouro_v *t, struct intern_name *tab,
			    int ntab, int depth);

static void write_term_list(FILE *f, ouro_v *xs, struct intern_name *tab,
			    int ntab, int depth)
{
	int first = 1;
	fputc('[', f);
	while (!list_done(xs)) {
		if (xs->tag != 1 || xs->n < 2)
			break;
		if (!first)
			fputc(',', f);
		first = 0;
		write_core_term(f, OURO_F(xs, 0), tab, ntab, depth);
		xs = OURO_F(xs, 1);
	}
	fputc(']', f);
}

static void write_core_term(FILE *f, ouro_v *t, struct intern_name *tab,
			    int ntab, int depth)
{
	const char *nm;
	if (t == 0 || depth > 256) {
		fputs("[\"Sort\",0]", f);
		return;
	}
	switch (t->tag) {
	case CT_REL:
		fprintf(f, "[\"Rel\",%lu]", as_nat(t->n >= 1 ? OURO_F(t, 0) : t));
		return;
	case CT_SORT:
		fprintf(f, "[\"Sort\",%lu]", as_nat(t->n >= 1 ? OURO_F(t, 0) : t));
		return;
	case CT_PI:
		if (t->n < 2) {
			fputs("[\"Sort\",0]", f);
			return;
		}
		fputs("[\"Pi\",\"_\"", f);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 0), tab, ntab, depth + 1);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 1), tab, ntab, depth + 1);
		fputc(']', f);
		return;
	case CT_LAM:
		if (t->n < 2) {
			fputs("[\"Sort\",0]", f);
			return;
		}
		fputs("[\"Lam\",\"_\"", f);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 0), tab, ntab, depth + 1);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 1), tab, ntab, depth + 1);
		fputc(']', f);
		return;
	case CT_APP:
		if (t->n < 2) {
			fputs("[\"Sort\",0]", f);
			return;
		}
		fputs("[\"App\",", f);
		write_core_term(f, OURO_F(t, 0), tab, ntab, depth + 1);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 1), tab, ntab, depth + 1);
		fputc(']', f);
		return;
	case CT_LET:
		if (t->n < 3) {
			fputs("[\"Sort\",0]", f);
			return;
		}
		fputs("[\"LetIn\",\"_\",", f);
		write_core_term(f, OURO_F(t, 0), tab, ntab, depth + 1);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 1), tab, ntab, depth + 1);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 2), tab, ntab, depth + 1);
		fputc(']', f);
		return;
	case CT_CONST:
		nm = artifact_name(tab, ntab, as_nat(t->n >= 1 ? OURO_F(t, 0) : t));
		fputs("[\"Const\",", f);
		json_quoted(f, nm[0] != 0 ? nm : "_");
		fputc(']', f);
		return;
	case CT_IND:
		nm = artifact_name(tab, ntab, as_nat(t->n >= 1 ? OURO_F(t, 0) : t));
		fputs("[\"Ind\",", f);
		json_quoted(f, nm[0] != 0 ? nm : "_");
		fputc(']', f);
		return;
	case CT_CTOR:
		if (t->n < 3) {
			fputs("[\"Sort\",0]", f);
			return;
		}
		nm = artifact_name(tab, ntab, as_nat(OURO_F(t, 0)));
		fputs("[\"Construct\",", f);
		json_quoted(f, nm[0] != 0 ? nm : "_");
		fprintf(f, ",%lu,%lu]", as_nat(OURO_F(t, 1)), as_nat(OURO_F(t, 2)));
		return;
	case CT_CASE:
		if (t->n < 4 || OURO_F(t, 0) == 0 || OURO_F(t, 0)->n < 3) {
			fputs("[\"Sort\",0]", f);
			return;
		}
		nm = artifact_name(tab, ntab, as_nat(OURO_F(OURO_F(t, 0), 0)));
		fputs("[\"Case\",{\"ind\":", f);
		json_quoted(f, nm[0] != 0 ? nm : "_");
		fprintf(f, ",\"nparams\":%lu,\"ctors\":",
			as_nat(OURO_F(OURO_F(t, 0), 1)));
		{
			ouro_v *xs = OURO_F(OURO_F(t, 0), 2);
			int first = 1;
			fputc('[', f);
			while (!list_done(xs)) {
				if (xs->tag != 1 || xs->n < 2)
					break;
				if (!first)
					fputc(',', f);
				first = 0;
				fprintf(f, "%lu", as_nat(OURO_F(xs, 0)));
				xs = OURO_F(xs, 1);
			}
			fputc(']', f);
		}
		fputs("},", f);
		write_core_term(f, OURO_F(t, 1), tab, ntab, depth + 1);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 2), tab, ntab, depth + 1);
		fputc(',', f);
		write_term_list(f, OURO_F(t, 3), tab, ntab, depth + 1);
		fputc(']', f);
		return;
	case CT_FIX:
		if (t->n < 5) {
			fputs("[\"Sort\",0]", f);
			return;
		}
		nm = artifact_name(tab, ntab, as_nat(OURO_F(t, 0)));
		fputs("[\"Fix\",", f);
		json_quoted(f, nm[0] != 0 ? nm : "_");
		fprintf(f, ",%lu,%lu,", as_nat(OURO_F(t, 1)), as_nat(OURO_F(t, 2)));
		write_core_term(f, OURO_F(t, 3), tab, ntab, depth + 1);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 4), tab, ntab, depth + 1);
		fputc(']', f);
		return;
	case CT_STR:
		nm = artifact_name(tab, ntab, as_nat(t->n >= 1 ? OURO_F(t, 0) : t));
		fputs("[\"StringLit\",", f);
		json_quoted(f, nm);
		fputc(']', f);
		return;
	default:
		fputs("[\"Sort\",0]", f);
	}
}

static void write_synth_type(FILE *f, ouro_v *t, struct intern_name *tab,
			     int ntab)
{
	if (t != 0 && t->tag == CT_LAM && t->n >= 2) {
		fputs("[\"Pi\",\"_\"", f);
		fputc(',', f);
		write_core_term(f, OURO_F(t, 0), tab, ntab, 0);
		fputc(',', f);
		write_synth_type(f, OURO_F(t, 1), tab, ntab);
		fputc(']', f);
		return;
	}
	if (t != 0 && t->tag == CT_FIX && t->n >= 5) {
		write_core_term(f, OURO_F(t, 3), tab, ntab, 0);
		return;
	}
	fputs("[\"Sort\",0]", f);
}

static int write_core_artifact(const char *path, const char *src,
			       ouro_v *cores, ouro_v *intern)
{
	FILE *f;
	struct intern_name *tab = 0;
	int ntab = 0;
	ouro_v *stack[256];
	ouro_v *cur;
	int sp = 0;
	int first = 1;
	const char *base;

	recover_names_from_intern(intern, &tab, &ntab);
	f = fopen(path, "wb");
	if (f == 0) {
		fprintf(stderr, "ouro1: cannot write core artifact %s\n", path);
		free(tab);
		return 1;
	}
	base = src != 0 ? src : "artifact";
	{
		const char *slash = strrchr(base, '/');
		const char *bslash = strrchr(base, '\\');
		if (bslash != 0 && (slash == 0 || bslash > slash))
			slash = bslash;
		if (slash != 0)
			base = slash + 1;
	}
	fputs("{\"kind\":\"ouro.kernel-core-artifact.v1\",\"name\":", f);
	json_quoted(f, base);
	fputs(",\"expect\":\"accept\",\"decls\":[", f);
	if (cores != 0)
		stack[sp++] = cores;
	while (sp > 0) {
		cur = stack[--sp];
		if (list_done(cur))
			continue;
		if (cur->tag == OURO_TAG_CAT && cur->n == 2) {
			if (sp + 2 <= 256) {
				stack[sp++] = OURO_F(cur, 1);
				stack[sp++] = OURO_F(cur, 0);
			}
			continue;
		}
		if (cur->tag == 1 && cur->n == 2) {
			ouro_v *pair = OURO_F(cur, 0);
			if (pair != 0 && pair->n >= 2) {
				unsigned long id = as_nat(OURO_F(pair, 0));
				const char *nm = artifact_name(tab, ntab, id);
				if (!first)
					fputc(',', f);
				first = 0;
				fputs("{\"kind\":\"def\",\"name\":", f);
				json_quoted(f, nm[0] != 0 ? nm : "_");
				fputs(",\"type\":", f);
				write_synth_type(f, OURO_F(pair, 1), tab, ntab);
				fputs(",\"body\":", f);
				write_core_term(f, OURO_F(pair, 1), tab, ntab, 0);
				fputc('}', f);
			}
			stack[sp++] = OURO_F(cur, 1);
			continue;
		}
	}
	fputs("]}\n", f);
	fclose(f);
	free(tab);
	fprintf(stderr, "ouro1: wrote core artifact %s\n", path);
	return 0;
}

static int valid_module_suffix(const char *suffix)
{
	const unsigned char *p = (const unsigned char *)suffix;

	if (p == 0 || *p == 0)
		return 1;
	if (*p++ != '_' || *p == 0)
		return 0;
	for (; *p != 0; p++) {
		if (!((*p >= 'a' && *p <= 'z') || (*p >= 'A' && *p <= 'Z') ||
		      (*p >= '0' && *p <= '9') || *p == '_'))
			return 0;
	}
	return 1;
}

int main(int argc, char **argv)
{
	ouro_v *fe;
	ouro_v *res;
	ouro_v *cores;
	unsigned long fuel = 600UL;
	int check_only = 0;
	const char *file = 0;
	const char *mod = "";
	const char *artifact_out = 0;
	char *units[MAX_UNITS];
	int nunits = 0;
	int i;

	i = 1;
	if (argc >= 2 && strcmp(argv[1], "check") == 0) {
		check_only = 1;
		i = 2;
	}
	for (; i < argc; i++) {
		if (strcmp(argv[i], "--unit") == 0 && i + 1 < argc) {
			if (nunits >= MAX_UNITS) {
				fputs("ouro1: too many --unit\n", stderr);
				return 2;
			}
			units[nunits++] = argv[++i];
		} else if (strcmp(argv[i], "--module") == 0 && i + 1 < argc) {
			mod = argv[++i];
		} else if (strcmp(argv[i], "--emit-core-artifact") == 0 &&
			   i + 1 < argc) {
			artifact_out = argv[++i];
		} else if (argv[i][0] == '-') {
			fprintf(stderr, "ouro1: unknown flag %s\n", argv[i]);
			return 2;
		} else if (file == 0) {
			file = argv[i];
		} else {
			fuel = strtoul(argv[i], 0, 10);
		}
	}

	if (file == 0) {
		fputs("usage: ouro1 [check] <file.ouro> [fuel] [--module SUF] [--unit PATH]... [--emit-core-artifact FILE]\n",
		      stderr);
		return 2;
	}
	if (!valid_module_suffix(mod)) {
		fputs("ouro1: --module must be empty or match _[A-Za-z0-9_]+\n",
		      stderr);
		return 2;
	}
	ouro_gc_set_stack_base(&argc);
	ouro_heap_report("process-start");
#ifdef _WIN32
	_setmode(_fileno(stdout), _O_BINARY);
#endif

	if (nunits > 0) {
		ouro_heap_report("before-unit-list");
		fe = find_in("compile_units", ouro_export_count_fe(),
			     ouro_export_name_fe, ouro_export_value_fe);
		res = ouro_apply(ouro_apply(ouro_apply(fe, ouro_nat(fuel)),
					path_bytes(file)),
			       unit_list_from(units, nunits));
		ouro_heap_report("after-compile-units");
	} else {
		ouro_heap_report("before-source-read");
		fe = find_in("compile_to_cores", ouro_export_count_fe(),
			     ouro_export_name_fe, ouro_export_value_fe);
		res = ouro_apply(ouro_apply(fe, ouro_nat(fuel)), file_codes(file));
		ouro_heap_report("after-compile-source");
	}

	if (res == 0 || res->tag != 1 || res->n < 1) {
		if (check_only)
			fputs("CHECK_FAIL: front end rejected the input\n", stderr);
		else
			fputs("ouro1: front end rejected the input\n", stderr);
		if (res != 0) {
			fprintf(stderr, "ouro1: CErr tag=%d n=%d\n", res->tag, res->n);
			if (res->n >= 1 && OURO_F(res, 0) != 0 && OURO_F(res, 0)->n >= 1) {
				unsigned long code = 0;
				unsigned long det = 0;
				ouro_v *e = OURO_F(res, 0);
				if (e->tag == OURO_TAG_NAT)
					code = (unsigned long)e->n;
				else if (e->n >= 1) {
					ouro_v *c = OURO_F(e, 0);
					while (c != 0 && c->tag == 1 && c->n == 1) {
						code++;
						c = OURO_F(c, 0);
					}
					if (c != 0 && c->tag == OURO_TAG_NAT)
						code += (unsigned long)c->n;
				}
				if (e->n >= 2) {
					ouro_v *d = OURO_F(e, 1);
					if (d != 0 && d->tag == OURO_TAG_NAT)
						det = (unsigned long)d->n;
					else {
						while (d != 0 && d->tag == 1 && d->n == 1) {
							det++;
							d = OURO_F(d, 0);
						}
					}
				}
				fprintf(stderr, "ouro1: CErr code=%lu det=%lu\n", code, det);
			}
			if (!check_only)
				ouro_show_line(res);
		}
		return 1;
	}
	if (!check_only)
		fprintf(stderr, "ouro1: compiled ok\n");

	if (check_only) {
		if (artifact_out != 0) {
			if (write_core_artifact(artifact_out, file, OURO_F(res, 0),
					       ouro_fe_last_intern()) != 0)
				return 1;
		}
		ouro_gc_push_root(&res);
		ouro_gc_collect();
		ouro_heap_report("check-ok-after-gc");
		ouro_gc_pop_roots(1);
		fputs("CHECK_OK\n", stdout);
		return 0;
	}

	cores = OURO_F(res, 0);
	{
		ouro_v **ids = 0;
		ouro_v **terms = 0;
		ouro_v *stack[256];
		ouro_v *cur;
		ouro_v *intern_perm = 0;
		int sp = 0;
		int n = 0;
		int cap = 64;
		ouro_v *extract_with;
		ouro_v *type_globals_fn;
		ouro_v *type_ids_v;
		ouro_v *emit_g;
		ouro_v *emit_f;
		ouro_v *emit_ex;
		ouro_v *hdr;
		ouro_v *nil;
		ouro_v *dummy;
		ouro_v *pieces;
		ouro_v *core_pairs;
		ouro_v *nlist;
		ouro_v *modv;
		ouro_v *fld[2];
		struct intern_name *tab = 0;
		int backend_failed = 0;
		int ntab = 0;

		/* Keep intern names and cores; drop the compile phase heap so
		   backend constants are not built on a spent bump bank. */
		if (getenv("OURO_EMIT_IO_SHIMS") != 0 && ouro_fe_last_intern() != 0)
			intern_perm = ouro_clone_perm(ouro_fe_last_intern());
		recover_names_from_intern(ouro_fe_last_intern(), &tab, &ntab);
		cores = ouro_clone_perm(cores);
		if (cores == 0) {
			fputs("ouro1: clone cores failed\n", stderr);
			backend_failed = 1;
			goto backend_done;
		}
		ouro_heap_discard_phase();
		ouro_heap_report("after-phase-discard");
		fputs("ouro1: walking cores\n", stderr);

		ids = (ouro_v **)malloc(sizeof(ouro_v *) * (unsigned)cap);
		if (ids == 0) {
			fputs("ouro1: out of memory\n", stderr);
			backend_failed = 1;
			goto backend_done;
		}
		terms = (ouro_v **)malloc(sizeof(ouro_v *) * (unsigned)cap);
		if (terms == 0) {
			fputs("ouro1: out of memory\n", stderr);
			backend_failed = 1;
			goto backend_done;
		}
		stack[sp++] = cores;
		while (sp > 0) {
			cur = stack[--sp];
			if (list_done(cur))
				continue;
			if (cur->tag == OURO_TAG_CAT && cur->n == 2) {
				if (sp + 2 > 256) {
					fputs("ouro1: cores nest too deep\n", stderr);
					backend_failed = 1;
					goto backend_done;
				}
				stack[sp++] = OURO_F(cur, 1);
				stack[sp++] = OURO_F(cur, 0);
				continue;
			}
			if (cur->tag == 1 && cur->n == 2) {
				ouro_v *pair = OURO_F(cur, 0);
				if (pair == 0 || pair->n < 2) {
					fputs("ouro1: core pair expected\n", stderr);
					backend_failed = 1;
					goto backend_done;
				}
				if (n == cap) {
					ouro_v **grown;
					if (n > 20000) {
						fprintf(stderr,
							"ouro1: too many cores n=%d (cycle?)\n",
							n);
						backend_failed = 1;
						goto backend_done;
					}
					cap *= 2;
					grown = (ouro_v **)realloc(
						ids, sizeof(ouro_v *) * (unsigned)cap);
					if (grown == 0) {
						fputs("ouro1: out of memory\n", stderr);
						backend_failed = 1;
						goto backend_done;
					}
					ids = grown;
					grown = (ouro_v **)realloc(
						terms, sizeof(ouro_v *) * (unsigned)cap);
					if (grown == 0) {
						fputs("ouro1: out of memory\n", stderr);
						backend_failed = 1;
						goto backend_done;
					}
					terms = grown;
				}
				ids[n] = OURO_F(pair, 0);
				terms[n] = OURO_F(pair, 1);
				n++;
				if ((n & 63) == 0) {
					fprintf(stderr, "ouro1: walk n=%d sp=%d\n", n, sp);
					fflush(stderr);
				}
				if (n > 5000) {
					fprintf(stderr,
						"ouro1: abort walk n=%d (cycle?)\n", n);
					backend_failed = 1;
					goto backend_done;
				}
				stack[sp++] = OURO_F(cur, 1);
				continue;
			}
			fputs("ouro1: cores is not a list\n", stderr);
			if (cur)
				fprintf(stderr, "ouro1: bad core cell tag=%d n=%d\n",
					cur->tag, cur->n);
			backend_failed = 1;
			goto backend_done;
		}
		fprintf(stderr, "ouro1: walked cores n=%d\n", n);

		extract_with = find_in("extract_term_with", ouro_export_count_be(),
				       ouro_export_name_be, ouro_export_value_be);
		type_globals_fn = find_in("type_globals", ouro_export_count_be(),
					  ouro_export_name_be,
					  ouro_export_value_be);
		emit_g = find_in("emit_global", ouro_export_count_be(),
				 ouro_export_name_be, ouro_export_value_be);
		emit_f = find_in("emit_fwd", ouro_export_count_be(),
			      ouro_export_name_be, ouro_export_value_be);
		emit_ex = find_in("emit_exports", ouro_export_count_be(),
				  ouro_export_name_be, ouro_export_value_be);
		hdr = find_in("c_hdr", ouro_export_count_be(),
			      ouro_export_name_be, ouro_export_value_be);

		fprintf(stderr, "ouro1: emit cores=%d names=%d\n", n, ntab);

		core_pairs = ouro_ctor(0, 0, 0);
		for (i = n - 1; i >= 0; i--) {
			ouro_v *pr[2];
			pr[0] = ids[i];
			pr[1] = terms[i];
			fld[0] = ouro_ctor(0, 2, pr);
			fld[1] = core_pairs;
			core_pairs = ouro_ctor(1, 2, fld);
		}
		type_ids_v = ouro_apply(
			ouro_apply(type_globals_fn, ouro_nat((unsigned long)n + 1UL)),
			core_pairs);
		type_ids_v = ouro_clone_perm(type_ids_v);
		if (type_ids_v == 0) {
			fputs("ouro1: clone type globals failed\n", stderr);
			backend_failed = 1;
			goto backend_done;
		}

		ouro_write_codes(hdr, stdout);
		for (i = 0; i < n; i++)
			ouro_write_codes(ouro_apply(emit_f, ids[i]), stdout);

		/* Standalone-program mode: bind runtime axioms and string
		   literals to the C host. Off by default so stage emission
		   stays byte-identical; scripts/build_tool.sh turns it on. */
		if (getenv("OURO_EMIT_IO_SHIMS") != 0)
			emit_runtime_shims(intern_perm, ids, n);

		for (i = 0; i < ouro_export_count_be(); i++)
			(void)ouro_export_value_be(i);
		ouro_rt_warmup();
		ouro_heap_mark();
		for (i = 0; i < n; i++) {
			const char *nm = lookup_name(tab, ntab, as_nat(ids[i]));
			if (nm != 0 && is_fast(nm) &&
			    !(g_ntype > 0 && is_fast_shape_mismatch(nm))) {
				unsigned long gid = as_nat(ids[i]);
				printf("static ouro_v *ouro_c%lu;\n", gid);
				printf("static ouro_v *ouro_g%lu(void){if(ouro_c%lu==0)"
				       "ouro_c%lu=ouro_fast(\"%s\");return ouro_c%lu;}\n",
				       gid, gid, gid, nm, gid);
				continue;
			}
			{
				ouro_v *ir;
				ouro_v *g1;
				ouro_v *chunk;
				ir = ouro_apply(ouro_apply(extract_with, type_ids_v),
					      terms[i]);
				if (g_ntype > 0 || g_str_base > 0)
					ir = rewrite_jsir(ir);
				g1 = ouro_apply(emit_g, ids[i]);
				if (g1 == 0 || g1->tag != OURO_TAG_CLOS) {
					fprintf(stderr,
						"ouro1: emit_global id[%d] not a function\n",
						i);
					backend_failed = 1;
					goto backend_done;
				}
				chunk = ouro_apply(g1, ir);
				ouro_write_codes(chunk, stdout);
				ouro_heap_reset();
			}
		}

		nil = ouro_ctor(0, 0, 0);
		fld[0] = ouro_nat(0);
		dummy = ouro_ctor(0, 1, fld);
		pieces = nil;
		for (i = n - 1; i >= 0; i--) {
			ouro_v *pr[2];
			pr[0] = ids[i];
			pr[1] = dummy;
			fld[0] = ouro_ctor(0, 2, pr);
			fld[1] = pieces;
			pieces = ouro_ctor(1, 2, fld);
		}
		nlist = names_list(tab, ntab, ids, n);
		modv = ouro_bytes((const unsigned char *)mod,
				  (unsigned long)strlen(mod));
		ouro_write_codes(
			ouro_apply(ouro_apply(ouro_apply(emit_ex, nlist), pieces), modv),
			stdout);
		ouro_gc_collect();
		ouro_heap_report("after-backend-emit");
	backend_done:
		free(ids);
		free(terms);
		free(tab);
		if (backend_failed)
			return 1;
		if (g_typearg_drops > 0)
			fprintf(stderr, "EXTRACT_TYPEARG count=%lu\n",
				g_typearg_drops);
	}
	return 0;
}
